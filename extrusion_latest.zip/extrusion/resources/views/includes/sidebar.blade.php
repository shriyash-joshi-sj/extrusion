<!-- Main Sidebar Container -->
  <aside class="main-sidebar elevation-4">
    <!-- Sidebar -->
    <div class="sidebar">

      <!-- Sidebar user (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="{{asset('logo.png')}}" alt="User Image" style="height: 135px !important; width: 100% !important;">
        </div>
      </div>

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

          <li class="nav-item">
            <a href="{{url('/dashboard')}}" class="nav-link {{ (Request::segment(1) == 'dashboard') ? 'active' : '' }}">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link {{ (Request::segment(1) == 'trailers-list' || Request::segment(1) == 'trailers-booking-list') ? 'active' : '' }}">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Trailers
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('/trailers-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Trailers List</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{url('/trailers-booking-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Trailers Booking List</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link {{ (Request::segment(1) == 'users-list' || Request::segment(1) == 'users-document-list') ? 'active' : '' }}">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Customers
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('/users-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Customers List</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="{{url('/users-document-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Documents List</p>
                </a>
              </li>
            </ul>
          </li>


          <li class="nav-item">
            <a href="#" class="nav-link {{ (Request::segment(1) == 'insurance-providers-list' || Request::segment(1) == 'state-list' || Request::segment(1) == 'location-list') ? 'active' : '' }}">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Masters
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('/insurance-providers-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Insurance Providers List</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="{{url('/state-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>State List</p>
                </a>
              </li> 
              <li class="nav-item">
                <a href="{{url('/location-list')}}" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Location List</p>
                </a>
              </li>
            </ul>
          </li>

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>