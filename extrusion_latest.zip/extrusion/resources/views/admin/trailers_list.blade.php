@extends('layouts.admin_layout')
@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Trailers List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
              <li class="breadcrumb-item active">Trailers List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="row float-right">
                  <button class="btn btn-custom" id="add_trailer">Add Trailer</button>                  
                </div>
              </div>
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
	                    <th>Name</th>
	                    <th>Size</th>
	                    <th>Address</th>
	                    <th>City</th>
	                    <th>State</th>
	                    <th>Country</th>
                      <th>Created Date</th>
	                    <th>Status</th>
	                    <th>Action</th>
	                  </tr>
                  </thead>
                  @if(count($trailers) > 0)
                  <?php 
                      $i = 1; 
                      $status = [
                        'wfa' => 'Waiting for Approval',
                        'booked' => 'Booked',
                        'notavailable' => 'Not Available',
                        'started' => 'Started',
                        'cancelled' => 'Cancelled',
                        'ended' => 'Ended',
                        'Verification' => 'Verification',
                        'maintenance' => 'Maintenance',
                        'available' => 'Available',
                      ];

                    $size = [
                      1 => "4' x 8'",
                      2 => "5' x 10'",
                      3 => "6' x 12'"
                    ];

                  ?>
	                  <tbody>
	                  	@foreach($trailers as $trailer)
		                  <tr>
		                    <td>{{$i++}}</td>
		                    <td>{{$trailer['trailerName']}}</td>
		                    <td>{{$size[$trailer['trailerSize']]}}</td>
		                    <td>{{$trailer['address']}}</td>
		                    <td>{{$trailer['city']}}</td>
		                    <td>{{$trailer['state']}}</td>
		                    <td>{{$trailer['country']}}</td>
                        <td>{{date('m-d-Y g:i A', strtotime($trailer['createdDateTime']))}}</td>
		                    <td>{{$status[$trailer['status']]}}</td>
		                    <td><a href="javascript:void(0)" class="edit custom-a" data-details="{{json_encode($trailer)}}"><i class="fas fa-edit"></i></a></td>
		                  </tr>
		                @endforeach
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>SNo</th>
	                    <th>Name</th>
	                    <th>Size</th>
	                    <th>Address</th>
	                    <th>City</th>
	                    <th>State</th>
	                    <th>Country</th>
                      <th>Created Date</th>
	                    <th>Status</th>
	                    <th>Action</th>
	                  </tr>
                  </tfoot>
                 @endif
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<div class="modal fade" id="trailer_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Trailer Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="{{url('/save-trailer')}}" id="add_trailer_form">
          @csrf
          <div class="form-group">
            <input type="hidden" name="id" id="id">
            <label for="recipient-name" class="col-form-label">Location</label>
             <select name="location" id="location" class="form-control">
              <option value="">Select Location</option>
              @foreach($locations as $location)
                @if($location['isActive'])
                  <option value="{{$location['id']}}">{{$location['address']}}</option>
                @endif
              @endforeach
            </select>
            <span class="text-danger" id="vlocation"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Trailer Name</label>
            <input type="text" class="form-control" name="name" id="name">
            <span class="text-danger" id="vname"></span>
          </div>
           <div class="form-group">
            <label for="message-text" class="col-form-label">Trailer Size</label>
            <select name="size" id="size" class="form-control">
              <option value="">Select Size</option>
              <option value="1">4' x 8'</option>
              <option value="2">5' x 10'</option>
              <option value="3">6' x 12'</option>
            </select>
            <span class="text-danger" id="vsize"></span>
          </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Status</label>
            <select name="status" id="status" class="form-control">
              <option value="">Select Status</option>
              <option value="wfa">Waiting for Approval</option>
              <option value="booked">Booked</option>
              <option value="notavailable">Not Available</option>
              <option value="started">Started</option>
              <option value="cancelled">Cancelled</option>
              <option value="ended">Ended</option>
              <option value="Verification">Verification</option>
              <option value="maintenance">Maintenance</option>
              <option value="available">Available</option>
            </select>
            <span class="text-danger" id="vstatus"></span>
          </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Active Status</label>
            <select name="is_active" id="is-active" class="form-control">
              <option value="1">Active</option>
              <option value="0">In Active</option>
            </select>
          </div>

          <input type="submit" class="btn btn-custom" value="Save">
        </form>
      </div>
    </div>
  </div>
</div>

 <script>

  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

    $('body').on('click', '#add_trailer', function(){
        $('.text-danger').text('');
        $('#id').val('');
        $('#add_trailer_form')[0].reset();
        $('#trailer_modal').modal('show');
    });

    $('body').on('submit', '#add_trailer_form', function(){
        event.preventDefault();
        $('.text-danger').text('');
        var check = 0;
        var name = $('#name').val();
        var locationName = $('#location').val();
        var size = $('#size').val();
        var status = $('#status').val();

        if(name.length == 0){
          $('#vname').text('Trailer name is required');
          check = 1;
        }
        if(locationName.length == 0){
          $('#vlocation').text('Please select location');
          check = 1;
        }
        if(size.length == 0){
          $('#vsize').text('Please select size of trailer');
          check = 1;
        }
        if(status.length == 0){
          $('#vstatus').text('Please select status');
          check = 1;
        }
        if(check == 1){
          return false;
        }

        $.ajax({
          type: "POST",
          url: "{{url('/save-trailer')}}",
          data: $('#add_trailer_form').serialize(),
          success: function(result){
            result = JSON.parse(result);
            if(result.success){
              location.reload(true);
            }else{
              alert("some thing went wrong");
            }
          }
        });
    });

    $('body').on('click', '.edit', function(){
        $('.text-danger').text('');
        $('#add_trailer_form')[0].reset();
        var data = $(this).data('details');
        $('#id').val(data.id);
        $('#size').val(data.trailerSize);
        $('#status').val(data.status);
        $('#name').val(data.trailerName);
        $('#location').val(data.locationId);
        $('#is-active').val(data.isActive);
        $('#trailer_modal').modal('show');
    });

  });
</script>
@endsection