@extends('layouts.admin_layout')
@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>State List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
              <li class="breadcrumb-item active">State List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="row float-right">
                  <button class="btn btn-custom" id="add_state">Add State</button>                  
                </div>
              </div>
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
	                    <th>Name</th>
	                    <th>Short Name</th>
                      <th>Status</th>
                      <th>Created On</th>
                      <th>Actions</th>
	                  </tr>
                  </thead>
                  @if(count($states) > 0)
                  @php $i = 1; @endphp
	                  <tbody>
	                  	@foreach($states as $state)
		                  <tr>
		                    <td>{{$i++}}</td>
		                    <td>{{$state['name']}}</td>
                        <td>{{$state['shortName']}}</td>
                        <td>{{($state['isActive']) ? 'Active' : 'In Active'}}</td>
                        <td>{{date('m-d-Y g:i A', strtotime($state['createdDateTime']))}}</td>
                        <td><a href="javascript:void(0)" class="edit custom-a" data-details="{{json_encode($state)}}"><i class="fas fa-edit"></i></a></td>
		                  </tr>
		                @endforeach
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>Sno</th>
                      <th>Name</th>
                      <th>Short Name</th>
                      <th>Status</th>
                      <th>Created On</th>
                      <th>Actions</th>
	                  </tr>
                  </tfoot>
                 @endif
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<div class="modal fade" id="state_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">State Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="{{url('/save-state')}}" id="add_state_form">
          @csrf
          <input type="hidden" name="id" id="id">
          <div class="form-group">
            <label for="message-text" class="col-form-label">State Name</label>
            <input type="text" class="form-control" name="name" id="name">
            <span class="text-danger" id="vname"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Short Name</label>
            <input type="text" class="form-control" name="short_name" id="short-name">
            <span class="text-danger" id="vshort-name"></span>
          </div>

          <div class="form-group">
            <label for="message-text" class="col-form-label">Active Status</label>
            <select name="is_active" id="is-active" class="form-control">
              <option value="1">Active</option>
              <option value="0">In Active</option>
            </select>
          </div>

          <input type="submit" class="btn btn-primary" value="Save">
        </form>
      </div>
    </div>
  </div>
</div>

 <script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

    $('body').on('click', '#add_state', function(){
        $('.text-danger').text('');
        $('#id').val('');
        $('#add_state_form')[0].reset();
        $('#state_modal').modal('show');
    });

    $('body').on('submit', '#add_state_form', function(){
        event.preventDefault();
        $('.text-danger').text('');
        var check = 0;
        var name = $('#name').val();
        if(name.length == 0){
          $('#vname').text('State name is required');
          check = 1;
        }
       
        if(check == 1){
          return false;
        }

        $.ajax({
          type: "POST",
          url: "{{url('/save-state')}}",
          data: $('#add_state_form').serialize(),
          success: function(result){
            result = JSON.parse(result);
            if(result.success && result.response.body!= null){
              location.reload(true);
            }else if(result.response.body == null){
              $('#vname').text('State already exists');
            }else{
              alert("some thing went wrong");
            }
          }
        });
    });

    $('body').on('click', '.edit', function(){
        $('.text-danger').text('');
        $('#add_state_form')[0].reset();
        var data = $(this).data('details');
        $('#id').val(data.id);
        $('#name').val(data.name);
        var isActive = (data.isActive) ? 1 : 0;
        $('#is-active').val(isActive);
        $('#short-name').val(data.shortName);
        $('#state_modal').modal('show');
    });

  });
</script>
@endsection