@extends('layouts.admin_layout')
@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Trailers Booking List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
              <li class="breadcrumb-item active">Trailers Booking List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
	                    <th>Location Id</th>
	                    <th>Trailer Id</th>
	                    <th>User Id</th>
	                    <th>Comments</th>
	                    <th>Trip Start Date</th>
	                    <th>Trip End Date</th>
	                    <th>Cost</th>
                      <th>Status</th>
                      <th>Created On</th>
	                  </tr>
                  </thead>
                  @if(count($bookings) > 0)
                  @php $i = 1; @endphp
	                  <tbody>
	                  	@foreach($bookings as $booking)
		                  <tr>
		                    <td>{{$i++}}</td>
		                    <td>{{$booking['locationId']}}</td>
		                    <td>{{$booking['trailerId']}}</td>
		                    <td>{{$booking['userId']}}</td>
		                    <td>{{$booking['comments']}}</td>
		                    <td>{{($booking['tripStartDateTime']) ? date('m-d-Y g:i A', strtotime($booking['tripStartDateTime'])) : '' }}</td>
                        <td>{{($booking['tripEndDateTime']) ? date('m-d-Y g:i A', strtotime($booking['tripEndDateTime'])) : ''}}</td>
		                    <td>{{$booking['cost']}}</td>
                        <td>{{$booking['status']}}</td>
                        <td>{{date('m-d-y g:i A', strtotime($booking['createdDateTime']))}}</td>
		                  </tr>
		                @endforeach
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>Sno</th>
                      <th>Location Id</th>
                      <th>Trailer Id</th>
                      <th>User Id</th>
                      <th>Comments</th>
                      <th>Trip Start Date</th>
                      <th>Trip End Date</th>
                      <th>Cost</th>
                      <th>Status</th>
                      <th>Created On</th>
	                  </tr>
                  </tfoot>
                 @endif
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

 <script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
@endsection