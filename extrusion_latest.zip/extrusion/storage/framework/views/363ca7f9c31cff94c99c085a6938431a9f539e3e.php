
<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="col-sm-6 mb-2">
            <h3 class="m-0">Trailers</h3>
        </div>
        <div class="row">
          <?php
            $trailerStatus = [
              'wfa' => 'Waiting for Approval',
              'booked' => 'Booked',
              'notavailable' => 'Not Available',
              'started' => 'Started',
              'cancelled' => 'Cancelled',
              'ended' => 'Ended',
              'Verification' => 'Verification',
              'maintenance' => 'Maintenance',
              'available' => 'Available',
            ];

          ?>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['total'])) ? $data['trailers']['total'] : 0); ?></h3>
                <p>Total</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['wfa'])) ? $data['trailers']['wfa'] : 0); ?> </h3>
                <p><?php echo e($trailerStatus['wfa']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['notavailable'])) ? $data['trailers']['notavailable'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['notavailable']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['booked'])) ? $data['trailers']['booked'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['booked']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
          </div>

           <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['started'])) ? $data['trailers']['started'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['started']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['cancelled'])) ? $data['trailers']['cancelled'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['cancelled']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['ended'])) ? $data['trailers']['ended'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['ended']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['Verification'])) ? $data['trailers']['Verification'] : 0); ?> </h3>
                <p><?php echo e($trailerStatus['Verification']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['maintenance'])) ? $data['trailers']['maintenance'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['maintenance']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php echo e((isset($data['trailers']['available'])) ? $data['trailers']['available'] : 0); ?></h3>
                <p><?php echo e($trailerStatus['available']); ?></p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
            </div>
          </div>


        </div>

        <div class="col-sm-6 mb-2">
            <h3 class="m-0">Users</h3>
        </div>
        <div class="row">

          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e($data['user']['total']); ?></h3>
                <p>Total</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo e($data['user']['notprovided']); ?></h3>
                <p>Not Provided</p>
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars"></i>
              </div>
            </div>
          </div>

          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo e($data['user']['inreview']); ?></h3>
                <p>In Review</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
            </div>
          </div>

        </div>

         <div class="col-sm-6 mb-2">
            <h3 class="m-0">Location</h3>
        </div>
        <div class="row">

          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?php echo e($data['location']['total']); ?></h3>
                <p>Total</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
            </div>
          </div>

        </div>
  
       
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\extrusion\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>