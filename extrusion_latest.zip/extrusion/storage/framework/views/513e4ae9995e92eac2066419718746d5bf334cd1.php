
<?php $__env->startSection('content'); ?>
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Customers List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Customers List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
	                    <th>Name</th>
	                    <th>Phone</th>
	                    <th>Email Id</th>
                      <th>Created On</th>
	                  </tr>
                  </thead>
                  <?php if(count($users) > 0): ?>
                  <?php $i = 1; ?>
	                  <tbody>
	                  	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                  <tr>
		                    <td><?php echo e($i++); ?></td>
		                    <td><?php echo e($user['firstName'].' '.$user['lastName']); ?></td>
		                    <td><?php echo e($user['phone']); ?></td>
		                    <td><?php echo e($user['emailId']); ?></td>
                        <td><?php echo e(date('m-d-Y g:i A', strtotime($user['createdDateTime']))); ?></td>
		                  </tr>
		                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>Sno</th>
                      <th>Name</th>
                      <th>Phone</th>
                      <th>Email Id</th>
                      <th>Created On</th>
	                  </tr>
                  </tfoot>
                 <?php endif; ?>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

 <script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
<?php $__env->stopSection(); ?>




<!-- {
    "id": "0c2922d8-d4b5-4fea-b7e8-df706002bdbb",
    "isActive": null,
    "createdDateTime": "2021-12-12 04:41:46",
    "modifiedDateTime": null,
    "createdBy": null,
    "modifiedBy": null,
    "deviceToken": null,
    "osType": null,
    "deviceId": null,
    "appVersion": null,
    "firstName": "Venky",
    "lastName": "Pokala",
    "phone": "+19705589009",
    "emailId": "venkypokala@gmail.com",
    "roleId": "5",
    "roleName": null,
    "imageUrl": null,
    "countryCode": "+1",
    "country": null
  }, -->
<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\extrusion\resources\views/admin/users_list.blade.php ENDPATH**/ ?>