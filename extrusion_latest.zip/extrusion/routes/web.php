<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('admin.login');
});

Route::post('/authenticate-admin', 'AdminController@authenticateAdmin');

Route::get('/logout', 'AdminController@logout');

Route::group(['middleware' => 'checkLogin'], function () {

    Route::get('/trailers-list', 'AdminController@trailersList');

    Route::get('/admin-profile', 'AdminController@profile');

    Route::get('/trailers-booking-list', 'AdminController@trailersBookingList');

    Route::get('/users-list', 'AdminController@usersList');

    Route::get('/users-document-list', 'AdminController@usersDocumentList');

    Route::get('/insurance-providers-list', 'AdminController@insuranceProvidersList');

    Route::get('/state-list', 'AdminController@stateList');

    Route::get('/location-list', 'AdminController@locationList');

    Route::get('/dashboard', 'AdminController@dashboard');

    Route::post('/save-trailer', 'AdminController@saveTrailer');

    Route::post('/save-state', 'AdminController@saveState');

    Route::post('/save-location', 'AdminController@saveLocation');

    Route::post('/save-insurance-provider', 'AdminController@saveInsuranceProvider');

    Route::post('/save-user-document', 'AdminController@saveUserDocument');
});



