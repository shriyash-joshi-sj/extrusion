@extends('layouts.admin_layout')
@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Location List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
              <li class="breadcrumb-item active">Location List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <div class="row float-right">
                  <button class="btn btn-primary" id="add_location">Add Location</button>                  
                </div>
              </div>
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
	                    <th>Address</th>
	                    <th>Locality</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Country</th>
                      <th>Created On</th>
                      <th>Actions</th>
	                  </tr>
                  </thead>
                  @if(count($locations) > 0)
                  @php $i = 1; @endphp
	                  <tbody>
	                  	@foreach($locations as $location)
		                  <tr>
		                    <td>{{$i++}}</td>
		                    <td>{{$location['address']}}</td>
                        <td>{{$location['locality']}}</td>
                        <td>{{$location['city']}}</td>
                        <td>{{$location['state']}}</td>
                        <td>{{$location['country']}}</td>
                        <td>{{date('d-m-Y', strtotime($location['createdDateTime']))}}</td>
                        <td><a href="javascript:void(0)" class="edit" data-details="{{json_encode($location)}}"><i class="fas fa-edit"></i></a></td>
		                  </tr>
		                @endforeach
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>Sno</th>
                      <th>Address</th>
                      <th>Locality</th>
                      <th>City</th>
                      <th>State</th>
                      <th>Country</th>
                      <th>Created On</th>
                      <th>Actions</th>
	                  </tr>
                  </tfoot>
                 @endif
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

<div class="modal fade" id="location_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Location Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="POST" action="{{url('/save-location')}}" id="add_location_form">
          @csrf
          <input type="hidden" name="id" id="id">
          <div class="form-group">
            <label for="message-text" class="col-form-label">Address</label>
            <input type="text" class="form-control" name="address" id="address">
            <span class="text-danger" id="vaddress"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Locality</label>
            <input type="text" class="form-control" name="locality" id="locality">
            <span class="text-danger" id="vlocality"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">City</label>
            <input type="text" class="form-control" name="city" id="city">
            <span class="text-danger" id="vcity"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">State</label>
            <input type="text" class="form-control" name="state" id="state">
            <span class="text-danger" id="vstate"></span>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Country</label>
            <input type="text" class="form-control" name="country" id="country">
            <span class="text-danger" id="vcountry"></span>
          </div>
          <input type="submit" class="btn btn-primary" value="Save">
        </form>
      </div>
    </div>
  </div>
</div>

 <script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });

     $('body').on('click', '#add_location', function(){
        $('.text-danger').text('');
        $('#add_location_form')[0].reset();
        $('#location_modal').modal('show');
    });

    $('body').on('submit', '#add_location_form', function(){
        event.preventDefault();
        $('.text-danger').text('');
        var check = 0;
        var address = $('#address').val();
        var city = $('#city').val();
        var locality = $('#locality').val();
        var country = $('#country').val();
        var state = $('#state').val();

        if(address.length == 0){
          $('#vaddress').text('Address is required');
          check = 1;
        }

        if(city.length == 0){
          $('#vcity').text('City is required');
          check = 1;
        }

        if(locality.length == 0){
          $('#vlocality').text('Locality is required');
          check = 1;
        }

        if(country.length == 0){
          $('#vcountry').text('Country is required');
          check = 1;
        }

        if(state.length == 0){
          $('#vstate').text('State is required');
          check = 1;
        }

        if(check == 1){
          return false;
        }

        $.ajax({
          type: "POST",
          url: "{{url('/save-location')}}",
          data: $('#add_location_form').serialize(),
          success: function(result){
            result = JSON.parse(result);
            if(result.success){
              location.reload(true);
            }else{
              alert("some thing went wrong");
            }
          }
        });
    });

    $('body').on('click', '.edit', function(){
        $('.text-danger').text('');
        $('#add_location_form')[0].reset();
        var data = $(this).data('details');
        $('#id').val(data.id);
        $('#address').val(data.address);
        $('#city').val(data.city);
        $('#locality').val(data.locality);
        $('#country').val(data.country);
        $('#state').val(data.state);
        $('#location_modal').modal('show');
    });

  });
</script>
@endsection