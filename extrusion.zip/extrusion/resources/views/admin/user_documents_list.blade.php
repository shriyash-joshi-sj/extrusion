@extends('layouts.admin_layout')
@section('content')
 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Customer Documents List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="{{url('/')}}">Home</a></li>
              <li class="breadcrumb-item active">Customer Documents List</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-body">
                <table id="example2" class="table table-bordered table-hover">
                  <thead>
	                  <tr>
	                    <th>Sno</th>
                      <th>Insurance Provider</th>
	                    <th>Insurance Number</th>
	                    <th>Insurance Document</th>
                      <th>Insurance Expire Date</th>
                      <th>DL Number</th>
                      <th>DL Document</th>
                      <th>DL Expire Date</th>
                      <th>Created On</th>
                      <th>Status</th>
	                  </tr>
                  </thead>
                  @if(count($documents) > 0)
                  <?php $i = 1; ?>
	                  <tbody>
	                  	@foreach($documents as $document)
		                  <tr>
		                    <td>{{$i++}}</td>
		                    <td>{{$document['insuranceProvider']}}</td>
                        <td>{{$document['insuranceNum']}}</td>
                        <td><a href="{{$document['insuranceDocUrl']}}" target="_blank">Document</a></td>
                        <td>{{date('d-m-Y', strtotime($document['insuranceDocExpDate']))}}</td>
		                    <td>{{$document['drivingLicNum']}}</td>
		                    <td><a href="{{$document['drivingLicDocUrl']}}" target="_blank">Document</a></td>
                        <td>{{date('d-m-Y', strtotime($document['drivingLicExpDate']))}}</td>
                        <td>{{date('d-m-Y', strtotime($document['createdDateTime']))}}</td>
                        <td>{{$document['status']}}</td>
		                  </tr>
		                @endforeach
	                  </tbody>
                  <tfoot>
	                  <tr>
	                  	<th>Sno</th>
                      <th>Insurance Provider</th>
                      <th>Insurance Number</th>
                      <th>Insurance Document</th>
                      <th>Insurance Expire Date</th>
                      <th>DL Number</th>
                      <th>DL Document</th>
                      <th>DL Expire Date</th>
                      <th>Created On</th>
                      <th>Status</th>
	                  </tr>
                  </tfoot>
                 @endif
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

 <script>
  $(function () {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
@endsection




<!-- {
      "id": "ac15dfdb-c39d-4acd-9d37-7096d7872601",
      "isActive": true,
      "createdDateTime": "2021-12-12 07:06:12",
      "modifiedDateTime": null,
      "createdBy": null,
      "modifiedBy": null,
      "insuranceNum": "21534664",
      "drivingLicNum": "6464646446644",
      "insuranceDocUrl": "https://s3.us-east-1.amazonaws.com/ptsdlive/eb19d97e-427f-4fd1-851c-db5a15dd3694-IMG_20211212_102621174.jpg",
      "drivingLicDocUrl": "https://s3.us-east-1.amazonaws.com/ptsdlive/6602fad4-1689-4492-969f-3555e199f774-IMG_20211212_102636536.jpg",
      "userId": "1c2922d8-d4b5-4fea-b7e8-df706002bdbb",
      "insuranceDocExpDate": "2021-12-20 00:00:00",
      "drivingLicExpDate": "2021-12-31 00:00:00",
      "insuranceProvider": "brahma",
      "drvingLicIssuedState": null,
      "status": "notprovided",
      "comments": null
    } -->