<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use GuzzleHttp\Client;

class AdminController extends Controller
{
    private $api_url;
    private $header = ["Content-Type" => "application/json"];
    private $guzzleClient;

   public function __construct(){
      $this->api_url = env('API_BASE_URL');
      $this->guzzleClient = new Client(['base_uri' => $this->api_url]);
   }

   public function authenticateAdmin(Request $request){
        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required'
        ]);

        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $body = ['entity' => $request->email, 'password' => $request->password];

        $guzzleResponse = json_decode($this->guzzleClient->request('POST', 
            $this->api_url.'/api/v1/login/verify_entity?entityType=email',  
            [
                "headers" => $this->header,
                "body" => json_encode($body)
            ]
        )->getBody()->getContents(), true);

        if($guzzleResponse['status'] == 400){
            $validator->errors()->add('email', 'Invalid Email');
            $validator->errors()->add('password', 'Invalid Password');
            return Redirect::back()->withErrors($validator);
        }

        $data = $guzzleResponse['body'];

        if($guzzleResponse['status'] == 200){
            $request->session()->put('uid', $data['id']);
            $request->session()->put('name', $data['firstName'].' '.$data['lastName']);
            $request->session()->put('phone', $data['phone']);
            $request->session()->put('emailId', $data['emailId']);
            return redirect('/dashboard');
        }

   }

   public function trailersList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/trailers/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $trailers = $guzzleResponse['body'];
      }else{
        $trailers = [];
      }

      //get Locations
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/locations/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $locations = $guzzleResponse['body'];
      }else{
        $locations = [];
      }

      return view('admin.trailers_list', compact('trailers', 'locations'));
   }

   public function trailersBookingList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/trailerBookings/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $bookings = $guzzleResponse['body'];
      }else{
        $bookings = [];
      }
      return view('admin.trailer_booking_list', compact('bookings'));
   }

   public function usersList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/users/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $users = $guzzleResponse['body'];
      }else{
        $users = [];
      }
      return view('admin.users_list', compact('users'));
   }

   public function insuranceProvidersList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/insuranceProviders/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $providers = $guzzleResponse['body'];
      }else{
        $providers = [];
      }
      return view('admin.insurance_providers_list', compact('providers'));
   }

   public function stateList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/states/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $states = $guzzleResponse['body'];
      }else{
        $states = [];
      }
      return view('admin.state_list', compact('states'));
   }

    public function locationList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/locations/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $locations = $guzzleResponse['body'];
      }else{
        $locations = [];
      }
      return view('admin.location_list', compact('locations'));
   }

   public function usersDocumentList(){
      $guzzleResponse = json_decode($this->guzzleClient
                        ->request('GET', '/api/v1/userdocuments/all')
                        ->getBody()->getContents(), true);

      if($guzzleResponse['status'] == 200){
         $documents = $guzzleResponse['body'];
      }else{
        $documents = [];
      }
      return view('admin.user_documents_list', compact('documents'));
   }

   public function saveTrailer(Request $request){
        $body = [
            'locationId' => $request->location, 
            'trailerName' => $request->name, 
            'trailerSize' => $request->size, 
            'status' => $request->status
        ];

        if($request->id){
            $body['id'] = $request->id;
            $url = $this->api_url.'/api/v1/trailers/modify_trailer';
        }else{
            $url = $this->api_url.'/api/v1/trailers/add_trailer';
        }

        $guzzleResponse = json_decode($this->guzzleClient->request('POST', 
            $url,  
            [
                "headers" => $this->header,
                "body" => json_encode($body)
            ]
        )->getBody()->getContents(), true);

        if($guzzleResponse['status'] == 200){
            return json_encode(['success' => true]);
        }else{
            return json_encode(['success' => false]);
        }
   }

   public function saveState(Request $request){
        $body = [
            'name' => $request->name, 
            'shortName' => $request->short_name,
        ];

        $url = $this->api_url.'/api/v1/state';

        if($request->id){
            $method = "PUT";
            $body['id'] = $request->id;  
        }else{
            $method = "POST";
        }
        $guzzleResponse = json_decode($this->guzzleClient->request($method, 
            $url,  
            [
                "headers" => $this->header,
                "body" => json_encode($body)
            ]
        )->getBody()->getContents(), true);

        if($guzzleResponse['status'] == 200){
            return json_encode(['success' => true]);
        }else{
            return json_encode(['success' => false]);
        }
   }

   public function saveLocation(Request $request){
        $body = [
            'address' => $request->address, 
            'locality' => $request->locality, 
            'city' => $request->city, 
            'state' => $request->state, 
            'country' => $request->country,
        ];

        if($request->id){
            $body['id'] = $request->id;
            $url = $this->api_url.'/api/v1/locations/modify_location';
        }else{
            $url = $this->api_url.'/api/v1/locations/add_location';
        }

        $guzzleResponse = json_decode($this->guzzleClient->request('POST', 
            $url,  
            [
                "headers" => $this->header,
                "body" => json_encode($body)
            ]
        )->getBody()->getContents(), true);

        if($guzzleResponse['status'] == 200){
            return json_encode(['success' => true]);
        }else{
            return json_encode(['success' => false]);
        }
   }

   public function saveInsuranceProvider(Request $request){
        $body = [
            'name' => $request->name, 
        ];
        $url = $this->api_url.'/api/v1/insuranceProviders';
        if($request->id){
            $body['id'] = $request->id;
            $method = "PUT";
        }else{
            $method = "POST";
        }
        $guzzleResponse = json_decode($this->guzzleClient->request($method, 
            $url,  
            [
                "headers" => $this->header,
                "body" => json_encode($body)
            ]
        )->getBody()->getContents(), true);

        if($guzzleResponse['status'] == 200){
            return json_encode(['success' => true]);
        }else{
            return json_encode(['success' => false]);
        }
   }

   public function logout(Request $request){
     $request->session()->flush();
     return redirect('/');
   }

   public function profile(Request $request){
     $data = [
        'name' => $request->session()->get('name'),
        'phone' => $request->session()->get('phone'),
        'emailId' => $request->session()->get('emailId'),
     ];   
     return view('admin.profile', compact('data'));
   }

   public function dashboard(){
     return view('admin.dashboard');
   }

}
